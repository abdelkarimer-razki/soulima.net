import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:cached_network_image/cached_network_image.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const SoulimaApp());
}

class SoulimaApp extends StatelessWidget {
  const SoulimaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Soulima',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xff141414),
        primaryColor: Colors.white,
        fontFamily: 'Inter',
        colorScheme: const ColorScheme.dark(
          primary: Colors.white,
          secondary: Color(0xff808080),
          surface: Color(0xff181818),
        ),
      ),
      home: const MainScreen(),
    );
  }
}

// ─── DATA MODELS ─────────────────────────────────────────────────────────────
class MediaItem {
  final int id;
  final String title;
  final String? overview;
  final String? posterPath;
  final String? backdropPath;
  final double voteAverage;
  final String? releaseDate;
  final List<int> genreIds;
  final bool isMovie;

  MediaItem({
    required this.id,
    required this.title,
    this.overview,
    this.posterPath,
    this.backdropPath,
    required this.voteAverage,
    this.releaseDate,
    required this.genreIds,
    required this.isMovie,
  });

  factory MediaItem.fromJson(Map<String, dynamic> json, bool isMovie) {
    return MediaItem(
      id: json['id'],
      title: isMovie ? (json['title'] ?? json['original_title'] ?? '') : (json['name'] ?? json['original_name'] ?? ''),
      overview: json['overview'],
      posterPath: json['poster_path'],
      backdropPath: json['backdrop_path'],
      voteAverage: (json['vote_average'] as num?)?.toDouble() ?? 0.0,
      releaseDate: isMovie ? json['release_date'] : json['first_air_date'],
      genreIds: List<int>.from(json['genre_ids'] ?? []),
      isMovie: isMovie,
    );
  }
}

class Season {
  final int id;
  final int seasonNumber;
  final String name;
  final int episodeCount;
  final String? posterPath;

  Season({
    required this.id,
    required this.seasonNumber,
    required this.name,
    required this.episodeCount,
    this.posterPath,
  });

  factory Season.fromJson(Map<String, dynamic> json) {
    return Season(
      id: json['id'],
      seasonNumber: json['season_number'],
      name: json['name'] ?? 'Season',
      episodeCount: json['episode_count'] ?? 0,
      posterPath: json['poster_path'],
    );
  }
}

class Episode {
  final int id;
  final int episodeNumber;
  final String name;
  final String? overview;
  final String? stillPath;

  Episode({
    required this.id,
    required this.episodeNumber,
    required this.name,
    this.overview,
    this.stillPath,
  });

  factory Episode.fromJson(Map<String, dynamic> json) {
    return Episode(
      id: json['id'],
      episodeNumber: json['episode_number'],
      name: json['name'] ?? '',
      overview: json['overview'],
      stillPath: json['still_path'],
    );
  }
}

// ─── TMDB API SERVICE ──────────────────────────────────────────────────────────
class TMDBService {
  static const String _apiKey = 'acc5f02e54fa612710d3245f53f29600';
  static const String _baseUrl = 'https://api.themoviedb.org/3';

  static Uri _buildUri(String path, [Map<String, String>? queryParams]) {
    final params = {'api_key': _apiKey};
    if (queryParams != null) params.addAll(queryParams);
    return Uri.parse('$_baseUrl$path').replace(queryParameters: params);
  }

  static Future<List<MediaItem>> _fetchList(String path, bool isMovie, [Map<String, String>? query]) async {
    try {
      final response = await http.get(_buildUri(path, query));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List results = data['results'] ?? [];
        return results.map((item) => MediaItem.fromJson(item, isMovie)).toList();
      }
    } catch (_) {}
    return [];
  }

  // Movies
  static Future<List<MediaItem>> getTrendingMovies() => _fetchList('/trending/movie/day', true);
  static Future<List<MediaItem>> getTopRatedMovies() => _fetchList('/movie/top_rated', true);
  static Future<List<MediaItem>> getNewReleaseMovies() => _fetchList('/movie/now_playing', true);
  static Future<List<MediaItem>> searchMovies(String query) => _fetchList('/search/movie', true, {'query': query});

  // Series
  static Future<List<MediaItem>> getTrendingSeries() => _fetchList('/trending/tv/day', false);
  static Future<List<MediaItem>> getTopRatedSeries() => _fetchList('/tv/top_rated', false);
  static Future<List<MediaItem>> getNewReleaseSeries() => _fetchList('/tv/on_the_air', false);
  static Future<List<MediaItem>> searchSeries(String query) => _fetchList('/search/tv', false, {'query': query});

  // Common details / Trailers
  static Future<String?> getYoutubeTrailer(int id, bool isMovie) async {
    final path = isMovie ? '/movie/$id/videos' : '/tv/$id/videos';
    try {
      final response = await http.get(_buildUri(path));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List results = data['results'] ?? [];
        final trailer = results.firstWhere(
          (v) => v['site'] == 'YouTube' && (v['type'] == 'Trailer' || v['type'] == 'Teaser'),
          orElse: () => null,
        );
        if (trailer != null) return trailer['key'];
      }
    } catch (_) {}
    return null;
  }

  static Future<List<Season>> getSeasons(int tvId) async {
    try {
      final response = await http.get(_buildUri('/tv/$tvId'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List seasons = data['seasons'] ?? [];
        return seasons
            .map((s) => Season.fromJson(s))
            .where((s) => s.seasonNumber > 0)
            .toList();
      }
    } catch (_) {}
    return [];
  }

  static Future<List<Episode>> getEpisodes(int tvId, int seasonNumber) async {
    try {
      final response = await http.get(_buildUri('/tv/$tvId/season/$seasonNumber'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List episodes = data['episodes'] ?? [];
        return episodes.map((e) => Episode.fromJson(e)).toList();
      }
    } catch (_) {}
    return [];
  }
}

// ─── MAIN APP PAGE WITH BOTTOM BAR ──────────────────────────────────────────
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;
  bool _showSearch = false;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  final List<Widget> _tabs = [
    const MovieTabWidget(),
    const TVTabWidget(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black.withOpacity(0.85),
        elevation: 0,
        title: _showSearch
            ? TextField(
                controller: _searchController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Search movies or shows...',
                  hintStyle: TextStyle(color: Colors.grey),
                  border: InputBorder.none,
                ),
                autofocus: true,
                onChanged: (val) {
                  setState(() {
                    _searchQuery = val;
                  });
                },
              )
            : Image.asset(
                'assets/soulimaWhiteLogo.png',
                width: 38,
                height: 38,
                errorBuilder: (_, __, ___) => const Text(
                  'SOULIMA',
                  style: TextStyle(fontWeight: FontWeight.black, fontSize: 22, letterSpacing: 2),
                ),
              ),
        actions: [
          IconButton(
            icon: Icon(_showSearch ? Icons.close : Icons.search, color: Colors.white),
            onPressed: () {
              setState(() {
                if (_showSearch) {
                  _searchController.clear();
                  _searchQuery = '';
                }
                _showSearch = !_showSearch;
              });
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _showSearch && _searchQuery.isNotEmpty
          ? SearchResultsWidget(query: _searchQuery)
          : _tabs[_currentIndex],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: Colors.white10, width: 0.8)),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          backgroundColor: const Color(0xff121212),
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey.withOpacity(0.5),
          selectedLabelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
          unselectedLabelStyle: const TextStyle(fontSize: 10),
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.movie_outlined, size: 22),
              activeIcon: Icon(Icons.movie, size: 22),
              label: 'Movies',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.tv_outlined, size: 22),
              activeIcon: Icon(Icons.tv, size: 22),
              label: 'TV Shows',
            ),
          ],
          onTap: (index) {
            setState(() {
              _currentIndex = index;
              _showSearch = false;
              _searchController.clear();
              _searchQuery = '';
            });
          },
        ),
      ),
    );
  }
}

// ─── SEARCH RESULTS GRID ──────────────────────────────────────────────────────
class SearchResultsWidget extends StatelessWidget {
  final String query;
  const SearchResultsWidget({super.key, required this.query});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<MediaItem>>(
      future: Future.wait([
        TMDBService.searchMovies(query),
        TMDBService.searchSeries(query),
      ]).then((lists) => [...lists[0], ...lists[1]]),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Colors.white));
        }
        final list = snapshot.data ?? [];
        if (list.isEmpty) {
          return const Center(child: Text('No results found.', style: TextStyle(color: Colors.grey)));
        }
        return GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 2 / 3,
          ),
          itemCount: list.length,
          itemBuilder: (context, idx) {
            final item = list[idx];
            return GestureDetector(
              onTap: () => DetailPopUp.show(context, item),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: CachedNetworkImage(
                  imageUrl: 'https://image.tmdb.org/t/p/w300${item.posterPath}',
                  placeholder: (_, __) => Container(color: Colors.white10),
                  errorWidget: (_, __, ___) => Container(
                    color: Colors.white10,
                    child: Center(
                      child: Text(
                        item.title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 10, color: Colors.grey),
                      ),
                    ),
                  ),
                  fit: BoxFit.cover,
                ),
              ),
            );
          },
        );
      },
    );
  }
}

// ─── MOVIES TAB VIEW ──────────────────────────────────────────────────────────
class MovieTabWidget extends StatefulWidget {
  const MovieTabWidget({super.key});

  @override
  State<MovieTabWidget> createState() => _MovieTabWidgetState();
}

class _MovieTabWidgetState extends State<MovieTabWidget> {
  late Future<List<List<MediaItem>>> _dataFuture;

  @override
  void initState() {
    super.initState();
    _dataFuture = Future.wait([
      TMDBService.getTrendingMovies(),
      TMDBService.getNewReleaseMovies(),
      TMDBService.getTopRatedMovies(),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<List<MediaItem>>>(
      future: _dataFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Colors.white));
        }
        final data = snapshot.data ?? [[], [], []];
        final trending = data[0];
        final newReleases = data[1];
        final topRated = data[2];

        final billboardItem = trending.isNotEmpty ? trending[0] : null;

        return SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (billboardItem != null) BillboardWidget(item: billboardItem),
              const SizedBox(height: 16),
              if (trending.isNotEmpty) TrendingRowWidget(list: trending, title: 'Trending Movies'),
              const SizedBox(height: 24),
              if (newReleases.isNotEmpty) HorizontalRowWidget(list: newReleases, title: 'New Releases'),
              const SizedBox(height: 24),
              if (topRated.isNotEmpty) HorizontalRowWidget(list: topRated, title: 'Top Rated'),
              const SizedBox(height: 48),
            ],
          ),
        );
      },
    );
  }
}

// ─── TV SHOWS TAB VIEW ─────────────────────────────────────────────────────────
class TVTabWidget extends StatefulWidget {
  const TVTabWidget({super.key});

  @override
  State<TVTabWidget> createState() => _TVTabWidgetState();
}

class _TVTabWidgetState extends State<TVTabWidget> {
  late Future<List<List<MediaItem>>> _dataFuture;

  @override
  void initState() {
    super.initState();
    _dataFuture = Future.wait([
      TMDBService.getTrendingSeries(),
      TMDBService.getNewReleaseSeries(),
      TMDBService.getTopRatedSeries(),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<List<MediaItem>>>(
      future: _dataFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Colors.white));
        }
        final data = snapshot.data ?? [[], [], []];
        final trending = data[0];
        final newReleases = data[1];
        final topRated = data[2];

        final billboardItem = trending.isNotEmpty ? trending[0] : null;

        return SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (billboardItem != null) BillboardWidget(item: billboardItem),
              const SizedBox(height: 16),
              if (trending.isNotEmpty) TrendingRowWidget(list: trending, title: 'Trending TV Shows'),
              const SizedBox(height: 24),
              if (newReleases.isNotEmpty) HorizontalRowWidget(list: newReleases, title: 'New Releases'),
              const SizedBox(height: 24),
              if (topRated.isNotEmpty) HorizontalRowWidget(list: topRated, title: 'Top Rated'),
              const SizedBox(height: 48),
            ],
          ),
        );
      },
    );
  }
}

// ─── GIANT HERO BILLBOARD ─────────────────────────────────────────────────────
class BillboardWidget extends StatelessWidget {
  final MediaItem item;
  const BillboardWidget({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Container(
      width: width,
      height: MediaQuery.of(context).size.height * 0.65,
      position: Clip.antiAlias,
      child: Stack(
        children: [
          CachedNetworkImage(
            imageUrl: 'https://image.tmdb.org/t/p/original${item.backdropPath ?? item.posterPath}',
            width: width,
            height: double.infinity,
            fit: BoxFit.cover,
            alignment: Alignment.topCenter,
          ),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  Colors.transparent,
                  Color(0xb3050505),
                  Color(0xff141414),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          Positioned(
            bottom: 24,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    item.title.toUpperCase(),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.5,
                      color: Colors.white,
                      shadows: [Shadow(color: Colors.black, blurRadius: 10, offset: Offset(0, 2))],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (item.releaseDate != null)
                        Text(
                          item.releaseDate!.split('-')[0],
                          style: const TextStyle(color: Colors.grey, fontSize: 13),
                        ),
                      if (item.releaseDate != null) const SizedBox(width: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, py: 2),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white38),
                          borderRadius: BorderRadius.circular(3),
                        ),
                        child: const Text('18+', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        '★ ${item.voteAverage.toStringAsFixed(1)}',
                        style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => PlayerPage(
                                  id: item.id,
                                  isMovie: item.isMovie,
                                  title: item.title,
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.play_arrow, color: Colors.black, size: 24),
                          label: const Text('Play', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 15)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => DetailPopUp.show(context, item),
                          icon: const Icon(Icons.info_outline, color: Colors.white, size: 22),
                          label: const Text('Info', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white.withOpacity(0.25),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

// ─── HORIZONTAL SCROLL LISTS ──────────────────────────────────────────────────
class HorizontalRowWidget extends StatelessWidget {
  final List<MediaItem> list;
  final String title;

  const HorizontalRowWidget({super.key, required this.list, required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 0.3),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 150,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: list.length,
            itemBuilder: (context, idx) {
              final item = list[idx];
              return GestureDetector(
                onTap: () => DetailPopUp.show(context, item),
                child: Container(
                  width: 100,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: CachedNetworkImage(
                      imageUrl: 'https://image.tmdb.org/t/p/w300${item.posterPath}',
                      fit: BoxFit.cover,
                      placeholder: (_, __) => Container(color: Colors.white10),
                      errorWidget: (_, __, ___) => Container(color: Colors.white10),
                    ),
                  ),
                ),
              );
            },
          ),
        )
      ],
    );
  }
}

// ─── TRENDING TOP 10 LIST WITH GIANT OVERLAPPING NUMBERS ─────────────────────
class TrendingRowWidget extends StatelessWidget {
  final List<MediaItem> list;
  final String title;

  const TrendingRowWidget({super.key, required this.list, required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 0.3),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 175,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: list.length > 10 ? 10 : list.length,
            itemBuilder: (context, idx) {
              final item = list[idx];
              final rank = idx + 1;
              return GestureDetector(
                onTap: () => DetailPopUp.show(context, item),
                child: Container(
                  width: 155,
                  margin: const EdgeInsets.only(right: 12),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      // Giant Outline Rank Number
                      Positioned(
                        left: -8,
                        bottom: -18,
                        child: Text(
                          '$rank',
                          style: TextStyle(
                            fontSize: 115,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -6,
                            fontFamily: 'Inter',
                            foreground: Paint()
                              ..style = PaintingStyle.stroke
                              ..strokeWidth = 3.5
                              ..color = Colors.white.withOpacity(0.45),
                          ),
                        ),
                      ),
                      // Movie Card
                      Positioned(
                        left: rank == 10 ? 60 : 50,
                        top: 10,
                        bottom: 10,
                        child: Container(
                          width: 105,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 8, offset: Offset(2, 4))],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: CachedNetworkImage(
                              imageUrl: 'https://image.tmdb.org/t/p/w300${item.posterPath}',
                              fit: BoxFit.cover,
                              placeholder: (_, __) => Container(color: Colors.white10),
                              errorWidget: (_, __, ___) => Container(color: Colors.white10),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        )
      ],
    );
  }
}

// ─── PREMIUM DETAILS POP-UP MODAL ─────────────────────────────────────────────
class DetailPopUp extends StatefulWidget {
  final MediaItem item;
  const DetailPopUp({super.key, required this.item});

  static void show(BuildContext context, MediaItem item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xff181818),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
      ),
      builder: (_) => DetailPopUp(item: item),
    );
  }

  @override
  State<DetailPopUp> createState() => _DetailPopUpState();
}

class _DetailPopUpState extends State<DetailPopUp> {
  String? _trailerKey;
  bool _isLoadingTrailer = true;

  @override
  void initState() {
    super.initState();
    _loadTrailer();
  }

  Future<void> _loadTrailer() async {
    final key = await TMDBService.getYoutubeTrailer(widget.item.id, widget.item.isMovie);
    if (mounted) {
      setState(() {
        _trailerKey = key;
        _isLoadingTrailer = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final item = widget.item;

    return Container(
      height: MediaQuery.of(context).size.height * 0.82,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Close button & Video/Backdrop banner
          Stack(
            children: [
              Container(
                width: width,
                height: width * 9 / 16,
                color: Colors.black,
                child: _isLoadingTrailer
                    ? const Center(child: CircularProgressIndicator(color: Colors.white))
                    : _trailerKey != null
                        ? InAppWebView(
                            initialUrlRequest: URLRequest(
                              url: WebUri('https://www.youtube.com/embed/$_trailerKey?autoplay=1&mute=1&playsinline=1&controls=0&modestbranding=1&loop=1&playlist=$_trailerKey'),
                            ),
                            initialSettings: InAppWebViewSettings(
                              allowsInlineMediaPlayback: true,
                              mediaPlaybackRequiresUserGesture: false,
                            ),
                          )
                        : CachedNetworkImage(
                            imageUrl: 'https://image.tmdb.org/t/p/original${item.backdropPath ?? item.posterPath}',
                            fit: BoxFit.cover,
                          ),
              ),
              Positioned(
                top: 14,
                right: 14,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: const BoxDecoration(color: Color(0xaa000000), shape: BoxShape.circle),
                    child: const Icon(Icons.close, color: Colors.white, size: 20),
                  ),
                ),
              ),
            ],
          ),
          // Details content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, py: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: -0.2),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      if (item.releaseDate != null)
                        Text(
                          item.releaseDate!.split('-')[0],
                          style: const TextStyle(color: Colors.grey, fontSize: 13),
                        ),
                      if (item.releaseDate != null) const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, py: 2),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white30),
                          borderRadius: BorderRadius.circular(3),
                        ),
                        child: const Text('18+', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        '★ ${item.voteAverage.toStringAsFixed(1)}',
                        style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PlayerPage(
                            id: item.id,
                            isMovie: item.isMovie,
                            title: item.title,
                          ),
                        ),
                      );
                    },
                    icon: const Icon(Icons.play_arrow, color: Colors.black, size: 22),
                    label: const Text('Play Now', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      minimumSize: Size(width, 42),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (item.overview != null && item.overview!.isNotEmpty)
                    Text(
                      item.overview!,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.white.withOpacity(0.8),
                        height: 1.5,
                        letterSpacing: 0.1,
                      ),
                    ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

// ─── FULL-SCREEN NATIVE VIDEO PLAYBACK PAGE WITH STREAM ACCORDIONS ──────────
class PlayerPage extends StatefulWidget {
  final int id;
  final bool isMovie;
  final String title;

  const PlayerPage({
    super.key,
    required this.id,
    required this.isMovie,
    required this.title,
  });

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  final List<Map<String, String>> _servers = [
    {'name': 'Server 1 (Vidsrc.net)', 'url': 'https://vidsrc.net/embed'},
    {'name': 'Server 2 (Vidsrc.to)', 'url': 'https://vidsrc.to/embed'},
    {'name': 'Server 3 (Embed.su)', 'url': 'https://embed.su/embed'},
    {'name': 'Server 4 (Vidsrc.pro)', 'url': 'https://vidsrc.pro/embed'},
    {'name': 'Server 5 (Vidsrc.me)', 'url': 'https://vidsrc.me/embed'},
    {'name': 'Server 6 (2embed.cc)', 'url': 'https://2embed.cc/embed'},
    {'name': 'Server 7 (Vidsrc.in)', 'url': 'https://vidsrc.in/embed'},
    {'name': 'Server 8 (Streamhide)', 'url': 'https://streamhide.to/embed'},
    {'name': 'Server 9 (Autoembed)', 'url': 'https://autoembed.cc/embed'},
    {'name': 'Server 10 (Moviedata)', 'url': 'https://moviedata.info/embed'},
  ];

  int _selectedServerIndex = 0;
  int _selectedSeason = 1;
  int _selectedEpisode = 1;
  bool _showDropdown = false;

  List<Season> _seasons = [];
  List<Episode> _episodes = [];
  bool _isLoadingTVData = false;

  @override
  void initState() {
    super.initState();
    if (!widget.isMovie) {
      _loadTVData();
    }
  }

  Future<void> _loadTVData() async {
    setState(() => _isLoadingTVData = true);
    final seasons = await TMDBService.getSeasons(widget.id);
    if (seasons.isNotEmpty) {
      _seasons = seasons;
      _selectedSeason = seasons[0].seasonNumber;
      await _loadEpisodes(_selectedSeason);
    }
    if (mounted) {
      setState(() => _isLoadingTVData = false);
    }
  }

  Future<void> _loadEpisodes(int seasonNum) async {
    final eps = await TMDBService.getEpisodes(widget.id, seasonNum);
    if (mounted) {
      setState(() {
        _episodes = eps;
        _selectedEpisode = eps.isNotEmpty ? eps[0].episodeNumber : 1;
      });
    }
  }

  String _buildEmbedUrl() {
    final base = _servers[_selectedServerIndex]['url']!;
    if (widget.isMovie) {
      return '$base/movie/${widget.id}?player=new&ds_lang=ar';
    } else {
      return '$base/tv/${widget.id}/$_selectedSeason/$_selectedEpisode?player=new&ds_lang=ar';
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final embedUrl = _buildEmbedUrl();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: Text(
          widget.title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Video Player Container
            Container(
              width: width,
              height: width * 9 / 16,
              color: Colors.black,
              child: InAppWebView(
                key: ValueKey(embedUrl),
                initialUrlRequest: URLRequest(url: WebUri(embedUrl)),
                initialSettings: InAppWebViewSettings(
                  allowsInlineMediaPlayback: true,
                  iframeAllowFullscreen: true,
                  mediaPlaybackRequiresUserGesture: false,
                ),
              ),
            ),
            // Server select bar
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _showDropdown = !_showDropdown;
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, py: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xff1f1f1f),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: Colors.white10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.dns, color: Colors.white70, size: 20),
                              const SizedBox(width: 10),
                              Text(
                                _servers[_selectedServerIndex]['name']!,
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          Icon(_showDropdown ? Icons.arrow_drop_up : Icons.arrow_drop_down, color: Colors.white),
                        ],
                      ),
                    ),
                  ),
                  if (_showDropdown) ...[
                    const SizedBox(height: 8),
                    Container(
                      maxHeight: 200,
                      decoration: BoxDecoration(
                        color: const Color(0xff181818),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: Colors.white10),
                      ),
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: _servers.length,
                        itemBuilder: (context, idx) {
                          final isSelected = _selectedServerIndex == idx;
                          return ListTile(
                            dense: true,
                            title: Text(
                              _servers[idx]['name']!,
                              style: TextStyle(
                                color: isSelected ? Colors.white : Colors.grey,
                                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                            trailing: isSelected ? const Icon(Icons.check, color: Colors.white, size: 16) : null,
                            onTap: () {
                              setState(() {
                                _selectedServerIndex = idx;
                                _showDropdown = false;
                              });
                            },
                          );
                        },
                      ),
                    )
                  ],
                  // TV Season / Episode Collapsible Accordions
                  if (!widget.isMovie) ...[
                    const SizedBox(height: 24),
                    const Text('SEASONS & EPISODES', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 0.5, color: Colors.white60)),
                    const SizedBox(height: 12),
                    if (_isLoadingTVData)
                      const Center(child: CircularProgressIndicator(color: Colors.white))
                    else ...[
                      // Season selector Row
                      SizedBox(
                        height: 38,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _seasons.length,
                          itemBuilder: (context, idx) {
                            final seasonNum = _seasons[idx].seasonNumber;
                            final isSel = _selectedSeason == seasonNum;
                            return GestureDetector(
                              onTap: () async {
                                setState(() {
                                  _selectedSeason = seasonNum;
                                });
                                await _loadEpisodes(seasonNum);
                              },
                              child: Container(
                                alignment: Alignment.center,
                                margin: const EdgeInsets.only(right: 8),
                                padding: const EdgeInsets.symmetric(horizontal: 16),
                                decoration: BoxDecoration(
                                  color: isSel ? Colors.white : const Color(0xff1c1c1c),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  'Season $seasonNum',
                                  style: TextStyle(
                                    color: isSel ? Colors.black : Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 16),
                      // Episodes list
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _episodes.length,
                        itemBuilder: (context, idx) {
                          final ep = _episodes[idx];
                          final isSel = _selectedEpisode == ep.episodeNumber;
                          return Card(
                            color: isSel ? const Color(0xff222222) : const Color(0xff141414),
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4),
                              side: BorderSide(color: isSel ? Colors.white30 : Colors.white10),
                            ),
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 16, py: 6),
                              leading: ClipRRect(
                                borderRadius: BorderRadius.circular(3),
                                child: ep.stillPath != null
                                    ? CachedNetworkImage(
                                        imageUrl: 'https://image.tmdb.org/t/p/w200${ep.stillPath}',
                                        width: 75,
                                        height: 50,
                                        fit: BoxFit.cover,
                                      )
                                    : Container(color: Colors.white10, width: 75, height: 50),
                              ),
                              title: Text(
                                'Ep ${ep.episodeNumber}: ${ep.name}',
                                style: TextStyle(
                                  fontWeight: isSel ? FontWeight.bold : FontWeight.normal,
                                  color: isSel ? Colors.white : Colors.white70,
                                ),
                              ),
                              subtitle: ep.overview != null
                                  ? Text(
                                      ep.overview!,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                                    )
                                  : null,
                              onTap: () {
                                setState(() {
                                  _selectedEpisode = ep.episodeNumber;
                                });
                              },
                            ),
                          );
                        },
                      )
                    ]
                  ],
                  const SizedBox(height: 48),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
