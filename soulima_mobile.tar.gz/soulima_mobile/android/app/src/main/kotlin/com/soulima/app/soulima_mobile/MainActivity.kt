package com.soulima.app.soulima_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
